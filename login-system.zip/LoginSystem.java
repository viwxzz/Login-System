import java.util.HashMap;
import java.util.Scanner;

public class LoginSystem {

    public static void main(String[] args) {

        HashMap<String, String> users = new HashMap<>();

        users.put("admin", "1234");
        users.put("user", "pass");

        Scanner sc = new Scanner(System.in);

        System.out.print("Username: ");
        String username = sc.nextLine();

        System.out.print("Password: ");
        String password = sc.nextLine();

        if (users.containsKey(username)
                && users.get(username).equals(password)) {

            System.out.println("Login Successful");
        } else {
            System.out.println("Invalid Credentials");
        }

        sc.close();
    }
}